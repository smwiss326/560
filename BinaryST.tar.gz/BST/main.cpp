#include <iostream>
#include "BST.h"
#include "dictionaryEntry.h"
#include  <string>
#include <fstream>
#include <vector>
using namespace std;

int main()

{
    bool testing = true;
    while(testing) {
        string readFile,outFile;
        readFile ="unsortedDictionary.txt";
        int num =0;
        BSTREEINT<string>* tree = new BST<string>();
        string str;
        ifstream myReadFile;
        myReadFile.open(readFile);
        vector<string> strvec;
        if (myReadFile.is_open()) {
            while (!myReadFile.eof()) {
              getline(myReadFile,str);
              if(str != ""){
                  strvec.push_back(str);
                  tree->add(str);
                  }
                }
            }
            cout<<"*************"<<endl;
            cout<<"* Test Menu * "<<endl;
            cout<<"*************"<<endl;
            cout<< "1. Add Entry"<<endl;
            cout<< "2. Search Entry"<<endl;
            cout<< "3. Delete Entry"<<endl;
            cout<< "4. Save tree in user-specified ordering"<<endl;
            cout<< "5. Quit"<<endl;
            cin>>num;
            if(num == 1 ){
               //*************ADD TESTING********************
                bool test1 = true;
                int choice = 0;
                cout<<"Please Select a word to add."<<endl;
                cout<<"Words will be added to a copied dictionary"<<endl;
                cout<<"1. Quizzlix - Plural of quizzle (see quizzle)"<<endl;
                cout<<"2. Dankmeme - An exceptional meme"<<endl;
                cout<<"3. Rekt - absolutely decimated"<<endl;
                cin >>choice;
                BSTREEINT<string>* userTree = tree->copy();
                if(choice == 1)
                {
                    string addn = "Quizzlix - Plural of quizzle (see quizzle)";
                    userTree->add(addn);
                    cout<<"save this?  [y/n] "<<endl;
                    string rsp;
                    cin >> rsp;
                    if(rsp == "y")
                        {
                        cout<<"filename?"<<endl;
                        string fileout;
                        cin>> fileout;
                        ofstream fout;
                        fout.open(fileout);
                        userTree->printTree("in",fout);
                        }
                }
                if(choice == 2)
                {
                    string addn = "Dankmeme - An exceptional meme";
                    userTree->add(addn);
                    cout<<"save this?  [y/n] "<<endl;
                    string rsp;
                    cin >> rsp;
                    if(rsp == "y")
                        {
                        cout<<"filename?"<<endl;
                        string fileout;
                        cin>> fileout;
                        ofstream fout;
                        fout.open(fileout);
                        userTree->printTree("in",fout);
                        }
                  }
                if(choice == 3)
                {
                    string addn = "Rekt - absolutely decimated";
                    userTree->add(addn);
                    cout<<"save this?  [y/n] "<<endl;
                    string rsp;
                    cin >> rsp;
                    if(rsp == "y")
                        {
                        cout<<"filename?"<<endl;
                        string fileout;
                        cin>> fileout;
                        ofstream fout;
                        fout.open(fileout);
                        userTree->printTree("in",fout);

                        }
                    }
                cout<<"More Tests? [y/n]"<<endl;
                string rsp;
                cin>>rsp;
                if(rsp == "y")
                    {
                        continue;
                    }
                else
                    {
                        break;
                    }

                }
            if(num == 2){
          //**************************SEARCH TESTING*************************
                bool test2 = true;
                int choice =0;
                cout<<"Please Select a word to search."<<endl;
                cout<<"1. Pantheon"<<endl;
                cout<<"2. Unprofitable"<<endl;
                cout<<"3. Abandon"<<endl;
                cin>>choice;
                if(choice == 1)
                {
                    string srch = "Pantheon  n. 1 building in which illustrious dead are buried or have memorials. 2 the deities of a people collectively. 3 temple dedicated to all the gods. [greek theion divine]";
                    cout<<tree->search(srch)<<endl;
                }
                if(choice == 2)
                {
                    string srch ="Unprofitable  adj. Not profitable";
                    cout<<tree->search(srch)<<endl;
                }
                if(choice == 3)
                {
                    string srch = "Abandon  �v. 1 give up. 2 forsake, desert. 3 (often foll. By to; often refl.) Yield to a passion, another's control, etc. �n. Freedom from inhibitions.  abandonment n. [french: related to *ad-, *ban]";
                    cout<<tree->search(srch)<<endl;

                }
                cout<<"More Tests? [y/n]"<<endl;
                string rsp;
                cin>>rsp;
                if(rsp == "y")
                    {
                        continue;
                    }
                else
                    {
                        break;
                    }
            }
            if(num==3){
     //**********************REMOVE TESTING***********************************
                cout<<"here"<<endl;
                bool test3 = true;
                int choice = 0;
                cout<<"Please Select a word to Remove from Dictionary"<<endl;
                cout<<"Word will be removed from copied Dictionary"<<endl;
                cout<<"1. Abbot"<<endl;  //Abbot  n. Head of a community of monks. [old english from latin abbas]
                cout<<"2. Usage"<<endl; //Usage  the use of not with verbs other than auxiliaries or be is now archaic except with participles and infinitives (not knowing, i cannot say; we asked them not to come).
                cout<<"3. Geese"<<endl; //Geese  pl. Of *goose.
                cout<<"4. WARRRGARRBL (demonstration of failed search/remove)"<<endl;
                BSTREEINT<string>* userTree = tree->copy();
                cin >>choice;
                if(choice == 1)
                    {
                    string rmv ="Abbot  n. Head of a community of monks. [old english from latin abbas]";
                    userTree->clearNode(rmv);
                    cout<<"save this?  [y/n] "<<endl;
                    string rsp;
                    cin >> rsp;
                    if(rsp == "y")
                        {
                        cout<<"filename?"<<endl;
                        string fileout;
                        cin>> fileout;
                        ofstream fout;
                        fout.open(fileout);
                        userTree->printTree("in",fout);

                        }
                    }
                if(choice == 2)
                    {
                    string rmv ="Usage  the use of not with verbs other than auxiliaries or be is now archaic except with participles and infinitives (not knowing, i cannot say; we asked them not to come).";
                    userTree->clearNode(rmv);
                    cout<<"save this?  [y/n] "<<endl;
                    string rsp;
                    cin >> rsp;
                    if(rsp == "y")
                        {
                        cout<<"filename?"<<endl;
                        string fileout;
                        cin>> fileout;
                        ofstream fout;
                        fout.open(fileout);
                        userTree->printTree("in",fout);

                        }
                    }
                if(choice == 3)
                    {
                    string rmv = "Geese  pl. Of *goose.";
                    userTree->clearNode(rmv);
                    cout<<"save this?  [y/n] "<<endl;
                    string rsp;
                    cin >> rsp;
                    if(rsp == "y")
                        {
                        cout<<"filename?"<<endl;
                        string fileout;
                        cin>> fileout;
                        ofstream fout;
                        fout.open(fileout);
                        userTree->printTree("in",fout);
                        }
                    }
                if(choice == 4)
                {
                    string rmv = "WARRRGARRBL";
                    userTree->search(rmv);
                }
                cout<<"More Tests? [y/n]"<<endl;
                string rsp;
                cin>>rsp;
                if(rsp == "y")
                    {
                        continue;
                    }
                else
                    {
                        break;
                    }

                }
            if(num ==4 ){
 //*************************PRINT TESTING*************************************
                BSTREEINT<string>* userTree = tree->copy();
                cout<<"Please type the name of the output File"<<endl;
                cin >>outFile;
                string order;
                cout<<"Please specify ordering of print"<<endl;
                cin >> order;
                ofstream fout;
                fout.open(outFile);
                userTree->printTree(order,fout);
                cout<<"More Tests? [y/n]"<<endl;
                string rsp;
                cin>>rsp;
                if(rsp == "y")
                    {
                        continue;
                    }
                else
                    {
                        break;
                    }
                }
            if(num==5){
  //**************************EXIT CONDITION***********************************
                    cout<<"GOODBYE!"<<endl;
                    testing = false;
                }
              }
             return 0;

}









