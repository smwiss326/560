
//STEPHEN WISS
//BST.hpp

template<typename T>
bool BST<T>::add(T value, Node<T>* subtree)
{
	if(m_root == nullptr)
	{
		m_root = new Node<T>();
		m_root -> setValue(value);
		return true;
	}
	T tempValue = subtree->getValue();
	Node<T>* tempLeft = subtree-> getLeft();
	Node<T>* tempRight = subtree-> getRight();

        if(value < tempValue)
	{


		if(tempLeft == nullptr )
		{
			tempLeft = new Node<T>();
			tempLeft-> setValue(value);
			subtree-> setLeft(tempLeft);

			return true;
		}

		add(value, tempLeft);


	}
        else if(value > tempValue)
	{

		if(tempRight == nullptr)

		{
			tempRight = new Node<T>();
			tempRight-> setValue(value);

			subtree-> setRight(tempRight);
			return true;
		}

		add(value, tempRight);

	}
	else
	{
		return false;
	}

}
template<typename T>
T BST<T> ::clearNode(T value)
{
     (clearIndex(m_root,value));
     T a;
     return a;


}
template<typename T>
Node<T>* BST<T> ::clearIndex(Node<T> *subTree, T value)
{

    if(value == subTree->getValue())
    {
        Node<T> *rv = nullptr;
        if(subTree ->getLeft() == nullptr)
        {
            if(subTree->getValue() == m_root->getValue() && subTree->getValue() == value)
            {
                rv = subTree->getRight();
                m_root = rv;
                return rv;

            }

            rv = subTree->getRight();
            subTree = rv;

            return rv;
        }
        else if(subTree->getRight() == nullptr)
        {
            if(subTree->getValue() == m_root->getValue() && subTree->getValue() == value)
            {
                rv = subTree->getLeft();
                m_root = rv;
                return rv;

            }
            rv = subTree->getLeft();
            subTree = rv;
            return rv;
        }
        else
        {
            Node<T>* succ = getSuccessor(subTree->getLeft());
            subTree->setValue(succ->getValue());
            subTree->setLeft(  clearIndex(subTree->getLeft(),succ->getValue()));
        }
    }
    else if(value < subTree->getValue())
    {
        subTree->setLeft(clearIndex(subTree->getLeft(),value));
    }
    else
    {
        subTree->setRight(clearIndex(subTree->getRight(),value));

    }
    return subTree;
}
template<typename T>
Node<T>* BST<T> :: getSuccessor(Node<T>* n)
{
    while(n->getRight()!=nullptr)
        n = n->getRight();
    return n;
}
template<typename T>
T BST<T> ::leftMost(Node<T>* subTree)
{
    if (subTree->getLeft() != nullptr)
    {
        return leftMost(subTree->getLeft());
    }

}
template<typename T>
void BST<T>::deleteTree(Node<T>* subTree)
{

	if(subTree-> getLeft() != nullptr)
		deleteTree(subTree-> getLeft());
	if(subTree->getRight() != nullptr)
		deleteTree(subTree-> getRight());
	delete subTree;
        subTree=nullptr;
}
template<typename T>
T BST<T>::search(T value, Node<T>* subTree) const throw(myException)
{

       if(subTree == nullptr)
       {
           std::cout<<"value not present in String"<<std::endl;
           T a;
           return a;
       }
       else if (value == subTree->getValue())
       {
           //cout<<"got here"<<endl;
           return subTree->getValue();
       }
       else if (value < subTree->getValue())
       {

           return search(value,subTree->getLeft());
       }
       else
       {

           return search(value,subTree->getRight());
       }

    cout<<"test."<<endl;

}
template<typename T>
T BST<T>::search(T value) const throw(myException)
{
     return search(value, m_root);
}
template<typename T>
T BST<T>::getbase()
{
    return m_root;
}
template<typename T>
void BST<T>::printTree(Node<T>* subTree, string order,ofstream& outFile) const
{

		if(order =="pre")
		{
			if(subTree == nullptr)
			{return; }

            outFile << subTree-> getValue() <<endl;
			printTree(subTree->getLeft(), order, outFile);
			printTree(subTree->getRight(), order, outFile);

		}
		else if(order == "in")
		{
			if(subTree == nullptr)
			{ return; }
			printTree(subTree-> getLeft(), order,outFile);
                        outFile << subTree-> getValue()<<endl;
			printTree(subTree-> getRight(), order, outFile);

		}
		else if(order =="post")
		{
			if(subTree == nullptr)
			{ return; }
			printTree(subTree-> getLeft(), order,outFile);
			printTree(subTree-> getRight(), order,outFile);
                        outFile << subTree-> getValue() <<endl;
		}


}
template<typename T>
BST<T>::BST()
{
	m_root = nullptr;
}
template<typename T>
BST<T>::BST(const BST<T>& other)
{
	m_root = nullptr;

	if(!(other.isEmpty()))
	{
		m_root = new Node<T>(*(other.m_root));
	}
	else
	{
		std::cout << "original tree is empty.\n";
	}

}
template<typename T>
BST<T>::~BST()
{
	if(m_root != nullptr)
	{
		deleteTree(m_root);
		this->m_root = nullptr;
	}
}
template<typename T>
BSTREEINT<T>* BST<T>::copy()
{
	BSTREEINT<T>* copy = new BST<T>( *(this));
	return copy;
}
template<typename T>
bool BST<T>::isEmpty() const
{
	if(m_root == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
template<typename T>
bool BST<T>::add(T value)
{
	return add(value, m_root);
}
template<typename T>
void BST<T>::printTree(string order, ofstream& outFile) const
{
	if(m_root == nullptr)
	{
		std::cout << "Tree is empty\n";
		return;
	}
	printTree(m_root, order, outFile);
	std::cout << "\n";
}









