//STEPHEN WISS
//BST.h
#ifndef BST_h
#define BST_h
#include "BSTREEINT.h"
#include "Node.h"
#include "myException.h"
#include <iostream>
#include <fstream>
template<typename T>
class BST : public BSTREEINT<T>
{
    //PRIVATE
	private:
	Node<T>* m_root;//base node
	bool add(T value, Node<T>* subtree);//adds element to specified subtree
	void deleteTree(Node<T>* subTree);//deleteTree
	T search(T value, Node<T>* subTree) const throw(myException);//returns the value from tree
	void printTree(Node<T>* subTree, string order, ofstream& outFile) const;//prints tree in specified order
    //PUBLIC
	public:
	BST();//Constructor
	BST(const BST<T>& other);//Constructor
	~BST();//Destructor
	BSTREEINT<T>* copy();//Copys to an empty tree
	bool isEmpty() const;//returns true if tree is empty, false otherwise
	bool add(T value);//public call to add 
        T clearNode(T value);//calls clearindex
	Node<T>* getSuccessor(Node<T>* n);//returns prev Node
	void printTree(string order,ofstream& outFile) const;//public call of printTree
	Node<T>* clearIndex(Node<T>* subTree, T value);//clears value from tree and links nodes as needed
	T leftMost(Node<T>* subTree);//returns leftmost node
	T search(T value) const throw(myException);//public call to search
        T getbase();//gets value of m_root
};
#include "BST.hpp"
#endif





