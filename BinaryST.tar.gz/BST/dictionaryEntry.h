//DICTIONARYENTRY.H
//STEPHEN WISS

#include <iostream>
#include <string>

#include "BST.h"

using namespace std;


class DictionaryEntry
{
private:
	std::string word;
	std::string defn;
public:
        DictionaryEntry()
        {
            word="";
            defn="";
        }
	DictionaryEntry(std::string w, std::string d)
	{
            word = w;
            defn = d;

        }
        string getWord()
        {
            return word;
        }
        string getDefn()
        {
            return defn;
        }
        void setWord(string w)
        {
            word =w;
        }
        void setDefn(string d)
        {
            defn = d;
        }
        friend   bool operator< ( DictionaryEntry d1,  DictionaryEntry d2)
        {
                return(d1.getWord()<d2.getWord());
        }
        friend bool operator== ( DictionaryEntry d1,  DictionaryEntry d2)
        {
            return(d1.getWord()==d2.getWord());
        }
        friend bool operator> ( DictionaryEntry d1,  DictionaryEntry d2)
        {
            return(d1.getWord()>d2.getWord());
        }
        friend ostream& operator<<(ostream& os,  DictionaryEntry& dt)
        {
            os<<dt.getWord()<< " " <<dt.getDefn()<<endl;
            return os;
        }
};

//getter

