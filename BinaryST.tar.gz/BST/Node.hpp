
#include "Node.h"
template<typename T>
Node<T>::Node()
{
	leftchd = nullptr;
	rightchd = nullptr;
}
template<typename T>
Node<T>::Node(const Node<T>& other)
{
	leftchd = nullptr;
	rightchd = nullptr;
	data= other.data;
	if(other.leftchd != nullptr)
	{
		leftchd = new Node<T>(*(other.leftchd));
	}
	if(other.rightchd != nullptr)
	{
		rightchd = new Node<T>(*(other.rightchd));
	}
	return;
}
template<typename T>
T Node<T>::getValue()
{
	return data;
}
template<typename T>
void Node<T>::setValue(T value)
{
	data = value;
}
template<typename T>
Node<T>* Node<T>::getLeft()
{
	return leftchd;
}
template<typename T>
Node<T>* Node<T>::getRight()
{
	return rightchd;
}
template<typename T>
void Node<T>::setLeft(Node<T>* left)
{
	leftchd = left;
}
template<typename T>
void Node<T>::setRight(Node<T>* right)
{
	rightchd = right;
}
