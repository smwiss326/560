
#ifndef NODE_H
#define NODE_H

template<typename T>
class Node
{
    //PRIVATE
	private:
	Node<T>* leftchd;//pointer to left
	Node<T>* rightchd;//point to right
	T data;//contents of node
    //PUBLIC
	public:
	Node();//constructor
	Node(const Node<T>& other);//copy constructor
	T getValue();//returns data
	void setValue(T value);//sets data
	Node<T>* getLeft();//returns leftchd
	Node<T>* getRight();//rightchd
	void setLeft(Node<T>* left);//sets leftchd
	void setRight(Node<T>* right);//sets rightchd
};
#include "Node.hpp"
#endif
