

//STEPHEN WISS
//BSTREEINT.H
#include <iostream>
#include "myException.h"
#include <fstream>
#ifndef BSTREEINT_H
#define BSTREEINT_H
template<typename T>
class BSTREEINT
{   //public
	public:
	virtual ~BSTREEINT(){};//constructor
        virtual void clearIndex(T value){};//virtual clear 
	virtual BSTREEINT* copy() = 0;//virtual copy
        virtual T clearNode(T value){};//virtual clear
	virtual bool isEmpty() const = 0;//virtual isEmpty
	virtual bool add(T value) = 0;//virtual add
	virtual T search(T value) const throw(myException) = 0;//virtual search
	virtual void printTree(string order, ofstream& outFile) const = 0;//virtual print
};
#endif
