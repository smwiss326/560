

/** @file NotFoundException.h */

#ifndef myException_h
#define myException_h

#include <stdexcept>
#include <string>

using namespace std;

class myException : public logic_error
{
public:
   myException(const char* message);
};
#endif
